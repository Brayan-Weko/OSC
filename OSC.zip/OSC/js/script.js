(function ($) {
    "use strict";

    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    new WOW().init();

    $(window).scroll(function () {
        if ($(this).scrollTop() > 45) {
            $('.navbar').addClass('sticky-top shadow-sm');
        } else {
            $('.navbar').removeClass('sticky-top shadow-sm');
        }
    });
    
    
    const $dropdown = $(".dropdown");
    const $dropdownToggle = $(".dropdown-toggle");
    const $dropdownMenu = $(".dropdown-menu");
    const showClass = "show";
    
    $(window).on("load resize", function() {
        if (this.matchMedia("(min-width: 992px)").matches) {
            $dropdown.hover(
            function() {
                const $this = $(this);
                $this.addClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "true");
                $this.find($dropdownMenu).addClass(showClass);
            },
            function() {
                const $this = $(this);
                $this.removeClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "false");
                $this.find($dropdownMenu).removeClass(showClass);
            }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
    });
    
    
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    $(document).ready(function () {
        var $videoSrc;
        $('.btn-play').click(function () {
            $videoSrc = $(this).data("src");
        });

        $('#videoModal').on('shown.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        })

        $('#videoModal').on('hide.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc);
        })
    });
})(jQuery);








const restaurants = [
    {
      nom: "Le Petit Dejeuner",
      categorie: "Petit-déjeuner",
      typeCuisine: "Français",
      image: "about-1.jpg",
      lieu: "5 Rue de la Paix",
      description: "Un endroit charmant pour commencer votre journée avec des plats frais.",
      plats: [
        { nom: "Croissant", image: "img1.jpg", prix: 2 },
        { nom: "Omelette", image: "img1.jpg", prix: 5 }
      ]
    },
    {
      nom: "Café du Matin",
      categorie: "Petit-déjeuner",
      typeCuisine: "Européen, Bio",
      image: "about-2.jpg",
      lieu: "10 Rue de Rivoli",
      description: "Petit café cosy avec des options bio et végétariennes.",
      plats: [
        { nom: "Smoothie Bowl", image: "smoothie.jpg", prix: 6 },
        { nom: "Pancakes", image: "pancakes.jpg", prix: 7 }
      ]
    },
    {
      nom: "Brunch Parisien",
      categorie: "Petit-déjeuner",
      typeCuisine: "Brunch, International",
      image: "about-3.jpg",
      lieu: "15 Avenue des Champs",
      description: "Un brunch complet avec des influences internationales.",
      plats: [
        { nom: "Avocado Toast", image: "avocado.jpg", prix: 8 },
        { nom: "Saumon Bagel", image: "bagel.jpg", prix: 9 }
      ]
    },
    {
      nom: "Bistro Délicieux",
      categorie: "Déjeuner",
      typeCuisine: "Français, Méditerranéen",
      image: "menu-1.jpg",
      lieu: "20 Rue Saint-Honoré",
      description: "Bistrot élégant offrant une cuisine française classique et méditerranéenne.",
      plats: [
        { nom: "Coq au Vin", image: "coqauvin.jpg", prix: 15 },
        { nom: "Ratatouille", image: "ratatouille.jpg", prix: 12 }
      ]
    },
    {
      nom: "Le Gourmet",
      categorie: "Déjeuner",
      typeCuisine: "Italien, Français",
      image: "menu-2.jpg",
      lieu: "25 Boulevard Haussmann",
      description: "Restaurant chic avec des plats italiens et français.",
      plats: [
        { nom: "Pizza Margherita", image: "pizza.jpg", prix: 14 },
        { nom: "Risotto aux Champignons", image: "risotto.jpg", prix: 16 }
      ]
    },
    {
      nom: "Saveurs du Monde",
      categorie: "Déjeuner",
      typeCuisine: "International, Fusion",
      image: "menu-3.jpg",
      lieu: "30 Rue de la République",
      description: "Cuisine fusion avec des saveurs du monde entier.",
      plats: [
        { nom: "Tacos Fusion", image: "tacos.jpg", prix: 10 },
        { nom: "Sushi Burrito", image: "sushiburrito.jpg", prix: 12 }
      ]
    },
    {
      nom: "La Table Étoilée",
      categorie: "Dîner",
      typeCuisine: "Français, Gastronomique",
      image: "menu-4.jpg",
      lieu: "35 Rue de la Paix",
      description: "Restaurant étoilé Michelin avec une cuisine française gastronomique.",
      plats: [
        { nom: "Foie Gras", image: "foiegras.jpg", prix: 25 },
        { nom: "Homard Thermidor", image: "homard.jpg", prix: 35 }
      ]
    },
    {
      nom: "Le Dîner Romantique",
      categorie: "Dîner",
      typeCuisine: "Européen, Romantique",
      image: "menu-5.jpg",
      lieu: "40 Rue Saint-Honoré",
      description: "Parfait pour un dîner romantique avec une cuisine européenne raffinée.",
      plats: [
        { nom: "Filet Mignon", image: "filetmignon.jpg", prix: 22 },
        { nom: "Chateaubriand", image: "chateaubriand.jpg", prix: 28 }
      ]
    },
    {
      nom: "Le Jardin Gourmand",
      categorie: "Dîner",
      typeCuisine: "Végétarien, Bio",
      image: "menu-6.jpg",
      lieu: "40 Rue Saint-Honoré",
      description: "Parfait pour un dîner romantique avec une cuisine européenne raffinée.",
      plats: [
        { nom: "Filet Mignon", image: "filetmignon.jpg", prix: 22 },
        { nom: "Chateaubriand", image: "chateaubriand.jpg", prix: 28 }
      ]
    }
]



function displayRestaurants(restaurants) {
    const restaurantGrid = document.querySelector('.restaurant-grid');
    restaurantGrid.innerHTML = '';
  
    restaurants.forEach(restaurant => {
      const restaurantElement = document.createElement('div');
      restaurantElement.classList.add('d-flex');
      restaurantElement.classList.add('align-items-center');
      restaurantElement.classList.add('col-lg-12');
  
      restaurantElement.innerHTML = `
        <div class="col-lg-6 mb-3">
            <div class="d-flex align-items-center">
                <img class="flex-shrink-0 img-fluid rounded" src="img/${restaurant.image}" alt="" style="width: 80px;">
                <div class="w-100 d-flex flex-column text-start ps-4">
                    <h5 class="d-flex justify-content-between border-bottom pb-2">
                        <span>${restaurant.nom}</span>
                        <span class="text-primary"><a href="detail.html" class="restaurant-link" data-restaurant-id="${restaurants.indexOf(restaurant)}" data-bs-toggle="modal" data-bs-target="#detailModal"><i class="fas fa-link"></i></a></span>
                    </h5>
                    <small class="fst-italic">${restaurant.typeCuisine}</small>
                </div>
            </div>
        </div>
      `;
      restaurantGrid.appendChild(restaurantElement);
    });
}

displayRestaurants(restaurants)


function afficherDetailsRestaurant(restaurantId) {
    const restaurant = restaurants[restaurantId];

    const restaurantDetail = document.querySelector('.detailresto');
    const restaurantElement = document.createElement('div');
    restaurantDetail.innerHTML = "";
    
    restaurantElement.innerHTML = `
        <img class="img-fluid w-50 rounded mb-5" src="img/${restaurant.image}" alt="${restaurant.nom}"/>
        <h1 class="mb-4">${restaurant.nom}</h1>
        <h3 class="mb-4">${restaurant.lieu}</h3>
        <h4 class="mb-4">${restaurant.typeCuisine}</h4>
        <p>${restaurant.description}</p>
    `;

    const restaurantPlatDetail = document.querySelector('.detailPlats');
    restaurantPlatDetail.innerHTML = "";
    restaurant.plats.forEach(plat => {
        const platElement = document.createElement('div');
        platElement.innerHTML = `
            <div class="team-item text-center rounded overflow-hidden">
                <div class="rounded-circle overflow-hidden m-4">
                    <img class="img-fluid" src="img/${plat.image}" alt="${plat.nom}">
                </div>
                <h5 class="mb-0">${plat.nom}</h5>
                <small>${plat.prix} €</small>
            </div>
        `;
        console.log(plat.image, plat.nom, plat.prix);
        restaurantPlatDetail.appendChild(platElement);
    });
    restaurantDetail.appendChild(restaurantElement);
}



const restaurantLinks = document.querySelectorAll(".restaurant-link");
    restaurantLinks.forEach((link) => {
    link.addEventListener("click", (event) => {
        event.preventDefault();
        const restaurantId = parseInt(link.getAttribute("data-restaurant-id"), 10);
        afficherDetailsRestaurant(restaurantId);
    });
});